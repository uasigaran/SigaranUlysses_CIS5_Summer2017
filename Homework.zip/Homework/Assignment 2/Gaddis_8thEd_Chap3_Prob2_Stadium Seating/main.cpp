/* 
 * File:   main.cpp
 * Author: Ulysses Sigaran
 * Created on June 27, 2017, 3:46 PM
 * Purpose: Stadium Seating
 */

//System Libraries
#include <iostream>  //Input - Output Library
using namespace std; //Name-space under which system libraries exist

//User Libraries

//Global Constants

//Function Prototypes

//Execution begins here
int main(int argc, char** argv) {
    
    //Declare variables
    float seatsA, //Class A seats
          seatsB, //Class B seats
          seatsC, //Class C seats
          tickA, tickB, tickC, //Tickets sold
          totSales; //Total Revenue from tickets sales
    
    
    //Initialize Variables
    seatsA=15.00f; //Cost of seats A in dollars
    seatsB=12.00f; //Cost of seats B in dollars
    seatsC=9.00; //Cost of seats C in dollars
    
    
    //Input the transformed data
    cout<<"Cost of Seating:"<<endl;
    cout<<"Enter Number of Tickets sold for Class A"<<endl;
    cin>>tickA;
    cout<<"Enter Number of Tickets sold for Class B"<<endl;
    cin>>tickB;
    cout<<"Enter Number of Tickets sold- for Class C"<<endl;
    cin>>tickC;
    
        
   //Calculations
    totSales=(seatsA*tickA)+(seatsB*tickB)+(seatsC*tickC);
  
    //Output
   cout<<"Total Revenue gained from total tickets sold= $"<<totSales<<endl;
            
    //Exit stage right!
    return 0;
}

