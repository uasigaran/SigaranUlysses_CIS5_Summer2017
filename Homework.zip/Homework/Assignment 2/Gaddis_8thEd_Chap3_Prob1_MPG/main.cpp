/* 
 * File:   main.cpp
 * Author: Ulysses Sigaran
 * Created on June 27, 2017, 3:46 PM
 * Purpose: Calculating MPG 
 */

//System Libraries
#include <iostream>  //Input - Output Library
using namespace std; //Name-space under which system libraries exist

//User Libraries

//Global Constants

//Function Prototypes

//Execution begins here
int main(int argc, char** argv) {
    
    //Declare variables
    float miles, // This will represent miles driven
            gallons, //This will represent gallons of gas
            mpg; //This will represent total mpg of a vehicle
    
    
    //Input the transformed data
    cout<<"Your Vehicle's MPG:"<<endl;
    cout<<"Enter # of Gallon Capacity in Vehicle's Tank"<<endl;
    cin>>gallons;
    cout<<"Enter # of Max Miles in 1 Full Tank"<<endl;
    cin>>miles;
    
        
    //Calculations Here
    mpg=miles/gallons;
  
    //Output
   cout<<"Miles Per Gallon (MPG)= "<<mpg<<endl;
            
    //Exit stage right!
    return 0;
}

