/* 
 * File:   main.cpp
 * Author: Ulysses Sigaran
 * Created on June 28, 2017, 11:03 AM
 * Purpose:  Box Office distribution
 */

//System Libraries
#include <iostream> //Input - Output Library
#include <string>
using namespace std; //Name-space under which system libraries exist

//User Libraries

//Global Constants

//Function Prototypes

//Execution begins here
int main(int argc, char** argv) {
    
    string name;
    
    //Declare variables
    float   adultS, //Adult Tickets Sold
            childS, //Child Tickets Sold
            adultT, //Price of Adult Tickets
            childT, //Price of Child Tickets
            percT, //Percentage Theater keeps
            grossB, //Gross Box Office Profit (dollars)
            netBox, //Net Box Office Profit (dollars)
            amtPaid; //Amount Paid to Distributor (dollars)
    
    //Initialize variables
    adultT=10.00f; //Dollars
    childT=6.00f; //Dollars
    percT=.20f; //Percentage Theater keeps
    
    //Input data
    cout<<"Theater's Gross and Net Office profit/ Night:"<<endl;
    cout<<"Enter Name of Movie"<<endl;
    getline(cin, name);
    cout<<"How many Adult Tickets sold?"<<endl;
    cin>>adultS;
    cout<<"How many Child Tickets sold?"<<endl;
    cin>>childS;
    
    //Calculations Here
    grossB=(adultS*adultT)+(childS*childT);
    netBox=(grossB*percT);
    amtPaid=(grossB-netBox);
    
    //Output the transformed data
    cout<<"Theater's Gross Box Office Profit  = $"<<grossB<<endl;
    cout<<"Theater's Net Box Office Profit    = $"<<netBox<<endl;
    cout<<"Amount Paid to Distributor         = $"<<amtPaid<<endl;
            
    //Exit stage right!
    return 0;
}

