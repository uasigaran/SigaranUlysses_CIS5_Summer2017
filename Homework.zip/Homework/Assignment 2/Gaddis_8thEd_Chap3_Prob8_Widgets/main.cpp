/* 
 * File:   main.cpp
 * Author: Ulysses Sigaran
 * Created on June 28, 2017, 11:32 PM
 * Purpose:  "How many Widgets?"
 */

//System Libraries
#include <iostream>  //Input - Output Library
using namespace std; //Name-space under which system libraries exist

//User Libraries

//Global Constants

//Function Prototypes

//Execution begins here
int main(int argc, char** argv) {
    
    //Declare variables
    float widget, //Weight of widgets
          numWidg, //Number of widgets on given pallet
          pallet, //Weight of given pallet by itself
          palWidg, //Weight of given pallet with widgets
          totWght; //Total weight of widget itself on given pallet
    
    //Initialize variables
    widget=12.5f; //Weight of widget in (lbs)
    
    //Input data
    cout<<"How much does the pallet weigh by itself?"<<"(lbs)"<<endl;
    cin>>pallet;
    cout<<"How much does the pallet weigh with the widgets?"<<"(lbs)"<<endl;
    cin>>palWidg;
    
    //Calculations Here
    totWght=(palWidg-pallet);
    numWidg=(totWght/widget);
    
    //Output the transformed data
    cout<<"Number of Widgets on the pallet= "<<numWidg<<" widgets"<<endl;
    //Exit stage right!
    return 0;
}

