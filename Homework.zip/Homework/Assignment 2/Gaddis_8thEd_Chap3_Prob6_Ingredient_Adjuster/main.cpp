/* 
 * File:   main.cpp
 * Author: Ulysses Sigaran
 * Created on June 27, 2017, 10:05 PM
 * Purpose:  Ingredient Adjuster
 */

//System Libraries
#include <iostream>  //Input - Output Library
using namespace std; //Name-space under which system libraries exist

//User Libraries

//Global Constants

//Function Prototypes

//Execution begins here
int main(int argc, char** argv) {
    //Declare variables
    float cSugar, cButter, cFlour, nSugar, 
          nButter, nFlour, totCook, cookies;
    
    //Initialize variables
    cSugar=1.5f;
    cButter=1.0f;
    cFlour=2.75f;
    totCook=48.0;
    
    //Input data
    cout<<"Calculate Cups Needed: "<<endl;
    cout<<"How many cookies do you want to make? "<<endl;
    cin>>cookies;
    
    //Calculations Here
    nSugar=(cSugar/totCook)*cookies;
    nButter=(cButter/totCook)*cookies;
    nFlour=(cFlour/totCook)*cookies;
    
    
    //Output the transformed data
    cout<<"Cups of sugar needed  = "<<nSugar<<endl;
    cout<<"Cups of butter needed = "<<nButter<<endl;
    cout<<"Cups of flour needed  = "<<nFlour<<endl;
    
    //Exit stage right!
    return 0;
}

