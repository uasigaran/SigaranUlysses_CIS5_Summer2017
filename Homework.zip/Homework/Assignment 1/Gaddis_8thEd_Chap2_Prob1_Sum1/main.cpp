/* 
 * File:   main.cpp
 * Author: Ulysses Sigaran 
 * Created on June 24, 2017, 1:24 PM
 * Purpose: Sum of Two Numbers
 */

//System Libraries
#include <iostream> //Input/Output
using namespace std;//Namespace of the System Libraries

//User Libraries

//Global Constants

//Function Prototypes

//Execution Begins Here!

/*
 * 
 */
int main(int argc, char** argv) {
    //Declare Variables
    int x = 50;
    int y = 100;
    float total;
    
    //Process the Data
    total = x +y;
    
    //Output the processed data
    cout<<x<<" + "<<y<<" = "<<total<<endl;
    //Exit Stage Right!
    return 0;
}

