/* 
 * File:   main.cpp
 * Author: Ulysses Sigaran
 * Created on June 21, 2017 2:05 AM
 * Purpose:  Sales Tax
 */

//System Libraries
#include <iostream>  //Input - Output Library
using namespace std; //Name-space under which system libraries exist

//User Libraries

//Global Constants

//Function Prototypes

//Execution begins here
int main(int argc, char** argv) {
    //Declare variables
    float statTax,//State Tax
          counTax,//County Tax
          totSale,//Total Sale
          itmCtax,//Item w/ County Tax
          itmStat,//Item w/ State Tax
          purch;//Purchased Item
            
            
    //Initialize variables
          statTax=.04f;
          counTax=.02f;
          purch=95.0f;
            
    //Calculations
          itmStat=purch*statTax;
          itmCtax=purch*counTax;
          totSale=(itmStat)+(itmCtax)+purch;
    
    //Output the transformed data
          cout<<"Item       = $"<<purch<<endl;
          cout<<"State Tax  = $"<<itmStat<<endl;
          cout<<"County Tax = $"<<itmCtax<<endl;
          cout<<"Total      = $"<<totSale<<endl;
          
    //Exit stage right!
    return 0;
}

