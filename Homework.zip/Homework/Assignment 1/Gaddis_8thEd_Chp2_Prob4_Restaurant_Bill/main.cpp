/* 
 * File:   main.cpp
 * Author: Ulysses Sigaran
 * Created on June 19, 2017, 9:27 PM
 * Purpose:  Restaurant Bill
 */

//System Libraries
#include <iostream>  //Input - Output Library
using namespace std; //Name-space under which system libraries exist

//User Libraries

//Global Constants

//Function Prototypes

//Execution begins here
int main(int argc, char** argv) {
    
    //Declare variables
    float percTip,//Percent of tip Charged
          tipAmt,//Tip Amount Charged
          mealTax,//Tax of the Meal
          taxAmt,//Tax Amount Charged
          mealChg,//Cost of Meal
          totBill;//Total Bill
         
    //Initialize variables
    percTip=.20f;
    mealTax=.0675f;
    mealChg=88.67f;
    
    //Process Calculations Here
    tipAmt=mealChg*percTip;
    taxAmt=mealTax*mealChg;
    totBill=(mealChg+tipAmt+taxAmt);
    
    
    //Output the transformed data
    cout<<"Meal Cost = $"<<mealChg<<endl;
    cout<<"Tax Amount= $"<<taxAmt<<endl;
    cout<<"Tip Amount= $"<<tipAmt<<endl;
    cout<<"Total Bill= $"<<totBill<<endl;
    
    
    //Exit stage right!
    return 0;
}

