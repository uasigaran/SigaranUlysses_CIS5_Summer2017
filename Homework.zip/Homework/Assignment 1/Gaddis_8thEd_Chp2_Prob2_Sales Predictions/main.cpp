/* 
 * File:   main.cpp
 * Author: Ulysses Sigaran
 * Created on June 20, 2017, 11:45 PM
 * Purpose:  Sales Predictions
 */

//System Libraries
#include <iostream>  //Input - Output Library
using namespace std; //Name-space under which system libraries exist

//User Libraries

//Global Constants

//Function Prototypes

//Execution begins here
int main(int argc, char** argv) {
    
    //Declare variables
    float percSale,//Percent East Coast Division contributes
          totSales,//Total Sales East Coast Division made
          finSales;//Final Sales after Calculations
    
    //Initialize variables
    percSale=.58f;//Percentage in decimal form
    totSales=8600000.0f;//Total Sales made hypothetically 
    
    //Input data
    finSales=(totSales*percSale);
               
    //Output the transformed data
    cout<<"Final Sales East Division Made= "<<(totSales*percSale)<<endl;
    //Exit stage right!
    return 0;
}

